# API Round-3 Verification — v3

**Reviewer:** API Designer · **Round:** 3 · **Date:** 2026-06-20
**Docs reviewed (v3):** connectivity-design, foundations-design, phase1a-lan-mvp-design, phase1b-robustness-design

---

## Round-2 issue verdicts

**RC2-08-API-001 (MAJOR) — Dual sequence mechanisms (clientMessageId vs clientSeq) ordering/dedup reconciliation**
RESOLVED. Foundations §3.1 now gives each counter an unambiguous, non-overlapping role: `clientSeq` is a strictly-monotonic per-seat ordering gate — the host accepts only the strictly-next value, a gap triggers `STALE_STATE`, out-of-order commands are not buffered. `clientMessageId` is an opaque retry de-dup key scoped to a match lifetime (move-log bounded). The two rules are in the same section and mutually exclusive in effect. Phase-0 exit criterion §5.3 mandates unit tests for the sequence reconciliation rule.

**RC2-08-API-002 (MINOR) — DealRound hand-distribution mechanism (broadcast vs per-seat SeatSnapshot)**
RESOLVED. Foundations §3.2 states explicitly: `DealRound` to clients carries only `roundId`, active seats, and `initialPlayerID`; hands are distributed by sending each client its own `SeatSnapshot` containing only `localHand`. No broadcast carries any hand. `dealSeed` is host-internal and prohibited from the wire (also enforced by the leakage oracle in §4.2 and §4.3).

**RC2-08-API-003 (MINOR) — LobbyUpdated payload schema typed**
RESOLVED. Foundations §4.1 (second bullet, "LobbyUpdated / StateDelta schemas") defines: `LobbyUpdated` carries `{ tableName, seats: SeatSummary[], canStart, hostSeatId }`. `SeatSummary` is typed in §4.1. Phase-0 exit criterion §5.3 requires `LobbyUpdated` to be typed in `protocol.ts`.

**RC2-08-API-004 (MINOR) — StateDelta schema defined or explicitly deferred**
RESOLVED. Foundations §4.1 defines `StateDelta` as a discriminated set of events — `MoveApplied`, `TrickWon`, `RoundDealt`, `RoundEnded` — each carrying `serverSeq`/`stateVersion`. It is a Phase 0 deliverable (exit criterion §5.3, traceability §6 lists RC2-API-004 as resolved). The client fallback on failed delta application (request full `SeatSnapshot`) is also specified.

---

## New issues

No new BLOCKER or MAJOR API/contract issues found.

Minor observations for the implementer's log (not blocking):

- The `StateDelta` event set (`MoveApplied`, `TrickWon`, `RoundDealt`, `RoundEnded`) is named but not field-typed in the spec. Payload fields for each variant will need to be pinned before `protocol.ts` is written. This is an implementation-phase task, not a spec gap that blocks design sign-off.
- The `GameOver` event (1A §3.7) is referenced in the rematch/game-over flow but does not appear in the Foundations §3.2 message union. It should be added there or explicitly called out as a Phase 1A extension to the union. Low risk since the client state machine already maps `phase === 'gameOver'` via `SeatView`, but the wire-level event should be in the discriminated union for `protocol.ts` completeness.

---

## Bottom line

CLEAR. All four round-2 API issues are fully addressed in v3. No new BLOCKER or MAJOR API/protocol gaps. The two minor observations above are implementation-phase bookkeeping and do not require a v4 revision.
