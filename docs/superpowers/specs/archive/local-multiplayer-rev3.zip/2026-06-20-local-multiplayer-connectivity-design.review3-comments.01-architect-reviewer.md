# Architect Round-3 Verification — v3

**Reviewer:** Architect (01) · **Date:** 2026-06-20 · **Source docs:** v3 of all four specs

---

## Round-2 issue verdicts

| ID | Title | Verdict | Evidence (doc · section) |
|---|---|---|---|
| RC2-01-ARCH-001 | Phase 0 exit must require clients/GameScreen consume ONLY SeatView, enforced by lint/type guard | **RESOLVED** | Foundations §2.3: "Clients consume only `SeatView` — `GameScreen` and every client component receive a `SeatView`, never `GameState`. Enforced by a typed boundary (the client store's type is `SeatView`) plus a lint/architecture rule forbidding imports of engine state types into client components — verified in CI, not by convention." Foundations §5 (exit criterion 5) makes it a Phase 0 gate. Connectivity changelog confirms it as RC2-ARCH-001. Both the type-guard mechanism and the CI-verified lint rule are now explicit; the fix is complete. |
| RC2-01-ARCH-002 | DealRound dealSeed host-vs-client distribution ambiguity | **RESOLVED** | Foundations §3.2: "`dealSeed` is host-internal and NEVER sent on the wire." The host deals locally, then sends each client only its own `SeatSnapshot` (`localHand` only); `DealRound` to clients carries `roundId`, active seats, and `initialPlayerID` only. Foundations §4.2 adds `dealSeed` to the hard prohibition list (test-gated, leakage oracle). Foundations §5 (exit criterion 4) gates Phase 0 on "dealSeed never appears in any serialized frame/log." Connectivity §10 v2→v3 changelog traces the fix to RC2-ARCH-002/RC2-SEC-002/RC2-API-002/RC2-GAME-003 across all four specs. Unambiguous. |
| RC2-01-ARCH-003 | Multi-interface address selection is a 1A QR prerequisite | **RESOLVED** | 1B §1.4 ("Address selection", NET-014): "Host chooses a guest-routable address across Wi-Fi/hotspot/VPN/multi-interface and IPv4 vs dual-stack/IPv6; the QR encodes a reachable candidate (offer alternates if several)." The concern about multi-interface ambiguity poisoning the QR-encoded URL is addressed by name. Placement in 1B is the only minor residual: the spec defers the implementation to 1B but the QR is a 1A deliverable. The risk is acknowledged (best-candidate selection drives 1A QR correctness) and the spec names it as an explicit deliverable, so implementation is not blocked — the decision is made, even if the code lands in a later phase. Minor only; does not reopen as a blocker. |

---

## New issues

One new MAJOR issue surfaced during the v3 scan.

### LMCD-RC3-01-ARCH-001 — MAJOR

**Title:** Address selection (NET-014) is scoped to 1B but is a functional prerequisite of the 1A QR/join URL

**Section:** 1B §1.4 (address selection), 1A §3.3 (pairing descriptor / QR), 1A §4 (acceptance criteria item 3 — "browser guest joins by scanning the QR")

**Concern:** The QR encodes `http://<host-ip>:<port>/join?room=<roomToken>`. The host-IP value must be the correct guest-routable address for the QR to work at all. On a real Android device with Wi-Fi + hotspot interfaces simultaneously active, picking the wrong interface (e.g. loopback, the hotspot-side IP when the guest is on the LAN, or a link-local `169.254.x.x`) produces a QR that silently fails every scan. This is not a latency/robustness concern — it is a correctness prerequisite for 1A acceptance criteria item 3. The spec currently places the implementation of address selection in 1B, after 1A ships. That ordering means 1A can be shipped/accepted with a hardcoded or guessed interface, which may pass on a controlled test bench but will fail in field conditions.

**Recommendation:** Either (a) pull a minimal implementation of NET-014 (enumerate non-loopback, non-link-local IPv4 addresses; prefer the Wi-Fi interface; offer alternates if multiple candidates exist) into 1A §1.1 (spike) or §3.3, explicitly making it a 1A exit criterion; or (b) add an explicit note that 1A acceptance criterion 3 cannot be signed off without validated multi-interface address selection, with a clear ownership marker so it is not silently assumed solved by the spike. The current text leaves a gap where 1A can be declared "done" on a lab bench that happens to have only one interface without ever exercising address selection.

---

**Minor note (not a blocker):** 1B §2.2 states heartbeat constants N and M "will be chosen in the spike" with proposed defaults of N=5 s, M=3. These are reasonable for a first cut and the spike-driven approach is fine. However, the spec does not state how the chosen values are recorded or become the normative reference for 1B implementation. A single sentence noting that the spike output will update a named constant file or config is sufficient to close this gap.

---

## Bottom line

**All three round-2 issues are RESOLVED.** One new MAJOR issue was identified (LMCD-RC3-01-ARCH-001): multi-interface address selection is categorised as a 1B deliverable but is a correctness prerequisite for 1A acceptance criterion 3 (QR join). This creates a phase-ordering gap that could allow 1A to be declared done while the QR is broken on real multi-interface devices. This must be reconciled before the 1A spec is considered exit-gate-ready.

**Exit gate: NOT-CLEAR**
