# Game Round-3 Verification — v3

**Reviewer:** Game Developer (03)
**Date:** 2026-06-20
**Scope:** game-logic issues from round-2 (RC2-03-GAME-001/002/003) + new blockers/majors.
**Docs checked:** connectivity-design v3, foundations v3, phase1a v3, phase1b v3.
**Engine checked:** `src/utils/cardsLogic.ts`, `movesLogic.ts`, `gameLogic.ts`, `roundLogic.ts`, `turnLogic.ts`, `src/types.ts`.

---

## Round-2 issue verdicts

### RC2-03-GAME-001 (MED) — canonical card-sort order pinned in hydrator/codec
**RESOLVED.**
Foundations §1.3 (RC2-GAME-001) now explicitly requires a total order on cards (`suit` then `rank`) and mandates that the codec/hydrator emit `cards` and `cardsBySuit` in that order. A property test is prescribed: "a shuffled-then-encoded hand yields the same `legalActions` as the original." This is the correct guard.

Engine check confirms the order is engine-consistent: `sortCards` in `cardsLogic.ts` uses `a.suit.localeCompare(b.suit) || a.rank - b.rank`; `dealCards` already sorts into `cardsBySuit` and rebuilds `cards` from the sorted per-suit arrays. The spec's canonical order matches the engine's existing convention, so the hydrator can implement it directly without divergence.

One residual implementation note (not a blocker): the spec requires the hydrator to also rebuild `cardsBySuit` from `cards` (not rely on the wire carrying `cardsBySuit`). This is implied by §1.3 ("snapshot hydrator rebuilds `cardsBySuit` from canonical `cards`") and by the round-trip property test; the implementer must be careful to apply `sortCards` per suit before appending to `cards`, exactly as `dealCards` does.

### RC2-03-GAME-002 (MED) — legalActions behavior outside 'playing' phase + phase→client-state mapping
**RESOLVED.**
Foundations §4.1 (RC2-GAME-002) now gives the full semantics:
- `legalActions` is non-empty **only** when `phase === 'playing'` AND `turn.currentSeatId === localSeatId`; it is `[]` in every other phase/turn.
- The client connection-state machine maps each phase to a UI mode: `lobby→lobby`, `dealing→syncing`, `playing→live` (input enabled only when `legalActions` non-empty), `roundEnd→round summary`, `gameOver→podium/rematch`.

This is a complete, unambiguous definition. The mapping covers all enumerated `phase` values in the `SeatView` schema (`lobby | dealing | playing | roundEnd | gameOver`), so there is no uncovered phase. `legalActions: []` as the default for all non-playing or out-of-turn states avoids any client-side inference.

### RC2-03-GAME-003 (LOW) — AI-before-DealRound reconnect snapshot edge case
**RESOLVED.**
The v3 fix is structural: `dealSeed` is now host-internal and never on the wire (Foundations §3.2, §4.2; connectivity-design v3→v3 changelog). The reconnect snapshot a client receives is a `SeatSnapshot` containing only its `localHand` (dealt by the host from the seed, projected via `projectStateForSeat`). The specific edge case — a reconnecting client arriving after AI has played one or more cards into a trick — is handled correctly:
- The host's `SeatSnapshot` carries the current `SeatView` (which includes `currentTrick` moves already made and the updated `localHand` if the AI played for this seat).
- `stateVersion` monotonicity ensures the client replaces any stale local view.
- 1B §2.3 specifies that the reconnecting player reclaims at the **next turn boundary**, so there is no race where the client and AI both think they hold the move.

The one remaining implementation note (not a blocker): the spec does not explicitly say that a `SeatSnapshot` issued mid-trick includes `currentTrick` moves already recorded — it is implied by `projectStateForSeat` projecting full `SeatView` including `currentTrick`, but a single sentence in the hydration/reconnect section confirming "snapshot carries all moves already in the current trick" would close the edge case completely. Low severity; file as a spec clarity note if desired.

---

## dealSeed host-internal change — fairness assessment

**CORRECT from a dealing/fairness standpoint.**

Previous concern: if `dealSeed` were on the wire, a client could predict all hands before being dealt. The v3 fix — host generates `dealSeed` internally, deals locally, then sends each client only its own `SeatSnapshot{localHand}` — is the correct cooperative-trust model for Phase 1 (F1). No player can infer another's hand from the wire.

The fairness invariant holds: all clients receive their hand from the same authoritative deal (seeded PRNG, deterministic for replay), and the seed never leaves the host. The spec correctly notes (Foundations §3.2) that the seed is "retained host-side solely for replay/host-internal verification (and, in a future F3, for post-round reveal)" — which is precisely the commitment needed for a future commit-reveal trustless deal. There is no fairness gap introduced by the change.

Engine note: `newRound` in `roundLogic.ts` currently calls `newPlayersHand(players)` without dealing (the deal is in `cardsLogic.dealCards` + `shuffleDeck`). The spec's seeded-PRNG requirement replaces `shuffleDeck`'s `Math.random` — this is a straightforward substitution at the engine layer, consistent with the "wrap, don't rewrite" principle in Foundations §1.

---

## New issues

### LMCD-RC3-03-GAME-001 (MAJOR) — `makeMove` reference match breaks under value-based rehydration; two removal paths can desync

**Severity:** MAJOR (correctness; silent data corruption in networked play)

**Location:** `gameLogic.ts` `makeMove` (line 62) + `dealCards` in `cardsLogic.ts` (lines 68–75).

**Issue:** `makeMove` finds the card to remove from `hand.cards` by **reference equality** (`c === playedCard`, `findIndex`). The spec (Foundations §1.3) correctly identifies this and specifies fixing it with value-based `(suit, rank)` matching. However, there is a second removal path in the same function: `hand.cardsBySuit[removedCard.suit].splice(cardInSuitIndex, 1)` also uses `findIndex(c => c === playedCard)` (line 88–91). Both removals must be converted to value-based matching atomically. If only the `hand.cards` removal is updated, `cardsBySuit` can desync from `cards` after a network round-trip, silently corrupting the duplicate-reference invariant that `validateSuit` depends on (it reads `hand.cards`, not `cardsBySuit`, but the hydrator rebuilds `cardsBySuit` from `cards` — a stale `cardsBySuit` after a move would break the hydrator's assumption).

**Required fix:** Both `findIndex` calls in `makeMove` must be updated to match by `(suit, rank)` together in the same PR. The spec mentions this in §1.3 but does not call out the dual-path risk explicitly. Add a test: play a card on a rehydrated (round-tripped) state and assert that both `cards` and `cardsBySuit` are consistent afterward.

### LMCD-RC3-03-GAME-002 (MAJOR) — `RoundResult.roundLosers` is a `Set`; codec must handle it before any serialization

**Severity:** MAJOR (wire correctness; silent loss of round-loser data)

**Location:** `roundLogic.ts` `computeRoundOutcome` (lines 44, 68); `types.ts` `RoundResult`.

**Issue:** `computeRoundOutcome` returns `roundLosers: Set<PlayerID>`. `JSON.stringify` of a `Set` produces `{}` — silently losing all losers. The Foundations spec (§1) acknowledges this as a known issue ("RoundResult.roundLosers is a Set → JSON.stringify gives {}") and §1.4 requires `WireGameState`/`WireRoundResult` with `Set → array` normalisation. This is a spec-acknowledged codec gap.

**Concern for v3:** the codec (`encode`/`decode`) is a Phase 0 deliverable (§1.4, §1.5) and must cover `RoundResult.roundLosers`. However, the `SeatView` schema (§4.1) does not expose `roundLosers` directly — but the `roundEnd` phase and podium logic depend on it. The **host-side** `projectStateForSeat` must correctly read `roundLosers` from the internal `RoundResult` (which is a `Set`) before projecting. If `projectStateForSeat` is implemented against a JSON-deserialised `GameState` (e.g. loaded from a log), and the codec's `Set→array→Set` round-trip is missed, the round-loser display will be silently wrong.

**Required fix:** the codec must include `RoundResult.roundLosers: Set → array` in both `encode` and `decode`. A round-trip property test for `RoundResult` (including the CAPOT path) must be part of Phase 0 acceptance (§1.5). This is implied by the spec but should be made explicit — the CAPOT branch (line 44–55 in `roundLogic.ts`) also sets `roundLosers` and must be covered.

---

## Bottom line

**NOT-CLEAR.**

All three round-2 issues are resolved in v3. The `dealSeed` host-internal change is correct. However, two MAJOR implementation traps exist in the engine that the spec does not call out precisely enough to guarantee a correct implementation:

1. **LMCD-RC3-03-GAME-001**: dual-path reference removal in `makeMove` — both `hand.cards` and `hand.cardsBySuit` removal must be switched to value-based matching together; the spec only mentions the `cards` path.
2. **LMCD-RC3-03-GAME-002**: `RoundResult.roundLosers` is a `Set`; the codec's `Set→array→Set` round-trip must cover this, and `projectStateForSeat` must read the live (non-serialised) `Set`, not a deserialised object — the spec requires the codec but doesn't call out the `roundLosers` field by name in the codec section.

Neither is a design flaw in the spec's approach; both are implementation precision gaps that can cause silent data corruption if missed. Recommend adding explicit call-outs to Foundations §1.3 (dual removal) and §1.4 (roundLosers codec) before Phase 0 implementation begins.
