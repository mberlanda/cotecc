# Expo/RN Round-3 Verification — v3

**Date:** 2026-06-20 · **Reviewer role:** Expo / React Native expert · **Round:** 3 (verifying v3)
**Scope:** RC2-05-EXPO-001/002/003 resolution check + new Expo/RN blocker/major scan.

---

## Round-2 issue verdicts

### RC2-05-EXPO-001 (HIGH) — build-time embed guard → RESOLVED

**Evidence:** 1A §1.3 (v3 changelog header + body): "Build-time embed guard (RC2-EXPO-001): the config plugin/build script must **fail the build** if `dist-embedded` is missing/stale or its hash doesn't match the freshly exported web artifact. `expo prebuild --clean` followed by a build must never silently produce a binary without the bundle — a packaged-asset + hash assertion runs in CI."

The guard is now a first-class spec requirement: it is named, attributed to RC2-EXPO-001, and tied to the CI gate defined in §4 (release gates include "Android prebuild/build"). The spike acceptance (§1.6) also requires "embedded bundle served + hash-verified." The mechanism is fully specified; implementation is a pre-spike concern, not a spec gap.

**Verdict: RESOLVED** in the spec.

---

### RC2-05-EXPO-002 (MED) — EAS Update vs binary decision → RESOLVED (with one residual note)

**Evidence:** 1A §1.3: "the embedded bundle ships **inside the binary** for 1A (no EAS Update OTA for the host-served assets), so the served bundle version always matches the running native host; OTA of host-served assets is explicitly out of scope until the runtime/version interaction is designed." The `runtimeVersion: { policy: "fingerprint" }` is named as the EAS profile policy.

The key concern (version skew between EAS Update JS delivery and the in-binary web bundle) is addressed by the decision to exclude host-served assets from OTA scope in 1A — if the native side gets an OTA update, the embedded bundle does not change. The fingerprint policy ensures binary compatibility gating.

**Residual note (non-blocking for spec):** `eas.json` does not yet exist in the repo. The development + preview profiles with `runtimeVersion: { policy: "fingerprint" }` cannot be validated until the spike lands them. This is a pre-implementation gap, not a spec gap, but it must be created before the first EAS build.

**Verdict: RESOLVED** in the spec; `eas.json` creation is a spike deliverable.

---

### RC2-05-EXPO-003 (MED) — expo-dev-client as Phase 1A dependency → RESOLVED

**Evidence:** 1A §1.3: "add `expo-dev-client`; **every** native participant (host and native guests, iOS and Android) runs a dev/preview build, not Expo Go, once the server/native module lands. `eas.json` gains development + preview profiles with a `runtimeVersion: { policy: 'fingerprint' }`."

The spec unambiguously names `expo-dev-client` as a required dependency and explicitly prohibits Expo Go for any native networking participant. The rollout boundary (dev/preview builds) is correctly gated on the spike landing native modules — Expo Go remains valid only for non-networking screens (§1.5).

**Current state of `package.json`:** `expo-dev-client` is absent from `dependencies`. This is expected pre-spike; the spec correctly identifies the addition as a spike deliverable.

**Verdict: RESOLVED** in the spec.

---

## New issues

### LMCD-RC3-05-EXPO-001 (MAJOR) — `web.output: "single"` incompatible with hashed-asset serving contract

**Location:** `CoteccApp/app.json` `"web": { "output": "single" }` vs 1A §1.2 + §1.3.

**Problem:** `app.json` sets `web.output: "single"` (Metro bundler, single-bundle mode). With this setting, `expo export --platform web` produces a flat, non-hashed output — a single JS file with no content-addressed asset manifest. This contradicts two spec requirements:

1. **§1.2 (static-serving contract):** "serve `index.html`, **hashed JS/CSS/image assets** with correct MIME types … cache/version strategy invalidated on app upgrade." Content hashing is how cache invalidation and the "stale bundle" guard work; single-mode output does not produce hashed filenames.
2. **§1.3 (embed guard):** "generate an asset **manifest + hash** → verify the packaged APK/IPA contains it and the hash matches the exported artifact." A single-mode export produces no per-asset manifest of this form.

If the spec's serving and guard logic is implemented against `output: "static"` conventions (hashed filenames, `asset-manifest.json`) but the project ships `output: "single"`, the CI hash assertion either cannot be implemented as described or will fail silently.

**Resolution path:** Either (a) switch to `web.output: "static"` (Metro static export, which produces hashed assets and a manifest), confirming SPA fallback still works for `/join` and `/game`; or (b) rewrite §1.2/§1.3 to specify the actual single-bundle approach (single JS file, ETag/Last-Modified for invalidation, hash of the whole file). Decision must be made during the spike (§1.1) before the embedding pipeline is designed.

**This is a MAJOR, not a blocker**, because the spec does not mandate `output: "static"` explicitly — it could be resolved either way — but the current mismatch will cause the spike to hit the contradiction immediately and risks the embed guard being designed against the wrong assumptions.

---

### LMCD-RC3-05-EXPO-002 (MAJOR) — No native socket library or config plugin identified; spike is the sole gate for all of 1A

**Location:** 1A §1.1 (mandatory spike) + `package.json`.

**Problem:** The spec correctly marks the spike as gating "the rest of 1A," but names no candidate socket library or config plugin. `package.json` has no native socket library. As of Expo SDK 56 / RN 0.85, the maintained options for an embedded HTTP+WS server in React Native are narrow: `react-native-tcp-socket` (TCP only, no HTTP abstraction), `react-native-http-server` (unmaintained), or a custom Expo Module. The spec says "a maintained SDK 56 / RN 0.85-compatible socket library **or** a local Expo Module" — but given the maintenance landscape, a custom Expo Module is the likely path, which adds non-trivial native code and a config plugin to Phase 1A scope.

**Why MAJOR:** If the spike concludes that a custom Expo Module is required, that discovery materially expands Phase 1A effort and changes the config-plugin story. This is expected from the spike, but the spec does not flag it as a risk or provide a fallback decision. If the spike stalls (no maintained library, Expo Module scope underestimated), Phase 1A has no gated alternative.

**Resolution path:** Add a spike risk note in §1.1 naming the two realistic outcomes (adopt a library vs build a module) and the Phase 1A scope impact of each; set a spike time-box after which the decision is forced.

---

## Bottom line

**Round-2 verdicts:** RC2-05-EXPO-001 RESOLVED · RC2-05-EXPO-002 RESOLVED · RC2-05-EXPO-003 RESOLVED.

**New issues:** 2 MAJOR (no new BLOCKER).
- LMCD-RC3-05-EXPO-001: `web.output: "single"` vs hashed-asset/manifest assumption in §1.2/§1.3 — must be resolved before the embedding pipeline is designed.
- LMCD-RC3-05-EXPO-002: no candidate socket library identified; spike outcome (library vs custom Expo Module) has material scope impact not flagged as a risk.

**Overall: NOT-CLEAR.** The three round-2 Expo issues are correctly addressed in the spec text. However, the `web.output: "single"` / hashed-asset contradiction (LMCD-RC3-05-EXPO-001) means the embedding pipeline spec and CI guard cannot be implemented as written against the current `app.json` without first resolving the export mode. This must be settled in the spike before the §1.3 design is finalized.
