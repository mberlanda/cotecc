# QA Round-3 Verification — v3

**Reviewer:** QA Expert (10)
**Date:** 2026-06-20
**Docs reviewed:** connectivity-design v3, foundations v3, phase1a v3, phase1b v3

---

## Round-2 issue verdicts

### RC2-10-QA-001 (BLOCKER) — CI-runnable harness for host-served bundle so Playwright runs headless without a device

**RESOLVED.**

The fix is fully specified. 1A §4.1 defines the CI harness: the embedded HTTP+WS server logic is factored into a headless Node host harness that serves the same exported `dist-embedded` bundle and speaks the same protocol. The CI flow is prescriptive: `expo export --platform web` → start Node harness → Playwright drives a browser against it. On-device runs are explicitly demoted to a supplementary lab gate (1B). The connectivity-design v3 changelog (§10 v2→v3) confirms the fix: "CI harness (headless Node host) so the host-served bundle is Playwright-testable (RC2-QA-001, the new blocker) — 1A §4.1."

Two execution gaps remain but are not blockers at spec stage: (a) the harness is specified but not yet implemented — the spec correctly positions it as a deliverable; (b) no CI YAML snippet or job name is pinned, so integration is still ambiguous at the pipeline level. These are implementation tasks, not spec gaps.

### RC2-10-QA-002 (MAJOR) — QR TTL / refresh cadence / expired-token error code specified and measurable

**RESOLVED.**

1A §3.3 specifies: room token TTL = **15 min** default; auto-refreshed while the lobby is open; QR shows a visible expiry/refresh indicator; expired token returns `Error{code: ROOM_TOKEN_EXPIRED}` with a "rescan" action. The failure taxonomy in 1B §1.2 adds a "Stale QR" row: signal = token TTL elapsed, message = "This code expired", primary action = rescan new code. The error code is part of the typed `Error{code}` envelope (Foundations §3.2), making it machine-assertable. The connectivity-design §10 changelog confirms: "QR/token TTL + refresh; … token expiry-at-match-end … (RC2-QA-002/003 …) — 1A §3.3 / 1B §1–§5."

One minor residual: the refresh cadence (how often the token is rotated within the 15-min window while the lobby is open) is described as "auto-refreshed" without specifying the interval (e.g. every 10 min, or on demand). This does not block implementation — a spec note or code constant suffices — but it is worth pinning before implementation to avoid divergence between host and client indicator logic.

### RC2-10-QA-003 (MAJOR) — Device lab is a falsifiable gate (inventory, physical-vs-emulated, evidence)

**RESOLVED.**

1B §4 specifies the lab as a fixed-inventory falsifiable gate. Minimum inventory is enumerated: Android host (≥ API 33), Chrome + Safari laptop browser guests, iOS app guest (≥ iOS 16), Android app guest. Network conditions are explicit: home router, client-isolated guest Wi-Fi, Android `LocalOnlyHotspot`, airplane-mode/no-internet LAN. Each cell records: device/OS version, **physical vs emulated** (host + hotspot cells MUST be physical), pass/fail, and an artifact (screen recording or log). The gate fails if any required physical cell is missing evidence.

The only residual ambiguity is that "≥ API 33" and "≥ iOS 16" are minimum bars but no maximum or representative recent version is named. In practice this is fine for alpha; worth revisiting when a new OS release lands during the 1B window.

---

## New issues

### LMCD-RC3-10-QA-001 (MAJOR) — Node harness fidelity contract is unspecified

**Location:** 1A §4.1

The CI harness is "factored from the embedded server logic" but the spec does not define what fidelity is required. Specifically: the harness must serve the same static-asset allowlist (1A §1.2), honour the same WS upgrade path and protocol envelope (Foundations §3), enforce the same schema/size caps (SEC-008), and use the same session/state machine as the on-device host. Without an explicit fidelity contract, divergence between the Node harness and the native host is undetectable until on-device testing. A Playwright-green CI run that passes against a lenient harness gives false confidence.

**Required fix:** add a short harness fidelity contract to 1A §4.1 or a new §4.2: list which server behaviours the harness must replicate verbatim vs which are out-of-scope (e.g. platform-specific bind/port selection). At minimum: same protocol version, same envelope schema, same asset allowlist enforcement, same session state machine. Include a CI assertion that the harness starts from the production server module, not a hand-rolled stub.

### LMCD-RC3-10-QA-002 (MAJOR) — Playwright gate scope is underspecified relative to 1A acceptance criteria

**Location:** 1A §4.1 vs §4 (acceptance criteria items 1–8)

The acceptance criteria in 1A §4 include eight items, several of which require protocol behaviour (item 5: legal/illegal move rejection with correct `MoveRejected{code}`; item 6: privacy/no-foreign-card leakage end-to-end; item 4: rejoin via token). The QA subset in §4.1 assigns these tests to "Jest for session/loopback … and Playwright for /join, lobby, manual join, joined-game render." The boundary is vague: it is unclear which of items 1–8 are covered by the CI harness+Playwright path, which by Jest alone, and which require the physical lab. If items 5–6 are Jest-only (against loopback), the Playwright+harness gate does not exercise the full host-served protocol path and the acceptance criteria are not fully automated.

**Required fix:** produce an explicit mapping table: each 1A acceptance criterion → test layer (Jest / Playwright+harness / physical lab) + CI-vs-lab gate. This is a one-page addition to 1A §4.1.

---

## Bottom line

**NOT-CLEAR.**

All three round-2 issues are resolved at the spec level. Two new MAJOR issues (LMCD-RC3-10-QA-001, LMCD-RC3-10-QA-002) prevent a CLEAR verdict: the CI harness lacks a fidelity contract, and the Playwright gate scope is not mapped to the acceptance criteria. Neither is a blocker to implementation starting, but both create measurable false-confidence risk before the 1A exit gate is evaluated. Resolve with a fidelity-contract paragraph and an acceptance-criterion-to-test-layer table in 1A §4.1.
