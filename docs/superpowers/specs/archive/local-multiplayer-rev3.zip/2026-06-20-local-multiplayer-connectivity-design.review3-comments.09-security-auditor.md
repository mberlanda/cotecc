# Security Round-3 Verification — v3

**Reviewer:** 09-security-auditor · **Date:** 2026-06-20 · **Docs reviewed:** connectivity-design v3, foundations v3, phase1a v3, phase1b v3

---

## Round-2 issue verdicts

**RC2-09-SEC-001 (MAJOR) — seatToken must NOT be in the join URL; issued post-join over the channel.**
RESOLVED. 1A §3.3 states explicitly: "No bearer credential in the URL (RC2-SEC-001): the per-seat resume (`seatToken`) is issued post-join by the host inside `SeatAssigned`, over the WS/SSE channel, and stored client-side (not in the address bar)." The join URL carries only `roomToken` (admission). Rationale (history, browser share-sheet leakage) is documented. Connectivity §10 v2→v3 changelog confirms the fix. The 1A traceability footer lists RC2-SEC-001 as resolved.

**RC2-09-SEC-002 (MAJOR) — dealSeed host-internal only, never on wire/log, added to redaction prohibition list.**
RESOLVED. Foundations §3.2 states "`dealSeed` is host-internal and NEVER sent on the wire (RC2-SEC-002)." The message union explicitly documents that `DealRound` to clients carries only `roundId`, active seats, and `initialPlayerID`. Foundations §4.2 (hard prohibitions) adds "`dealSeed` / any RNG state (RC2-SEC-002)" to the outbound/log/debug/snapshot allowlist exclusions with a test oracle requirement. Phase 0 exit criterion 4 requires "`dealSeed` never appears in any serialized frame/log." Connectivity §10 changelog confirms. Fully addressed across the prohibition list, wire schema, and exit gate.

**RC2-09-SEC-003 (LOW) — seat-squatting window / token bounded + expire at match end.**
RESOLVED. 1B §2.3 specifies: "a `disconnected` seat's resume token stays valid for a bounded reclaim window (default = AI timeout + a grace margin, host-configurable); after it elapses the host may free the seat (host action) and the stale token is invalidated. All seat tokens expire at match end regardless." The default AI timeout is 30 s (10–120 s range or pause-only). This closes both the squatting window and the unbounded-lifetime risk. 1B traceability lists RC2-SEC-003. Connectivity §10 changelog confirms.

**SEC-003 (round-1 partial) — token rotation-on-reconnect sequence pinned.**
RESOLVED. 1B §3 pins the sequence: "on every successful reconnect the host issues a new resume token in `SeatAssigned`, invalidates the previous one atomically, and rejects any later use of the old token with `BAD_SEAT_TOKEN`; only one token is ever valid per seat at a time." This closes the race window left open after round-1. 1B traceability footer lists SEC-003 and RC2-SEC-003. The rotation is also part of the 1B exit gate through the security hardening cluster H verification requirement.

---

## New issues

No new BLOCKER or MAJOR security issues found. Observations for the record (all LOW / informational, no action required before implementation):

- **LMCD-RC3-09-SEC-001 (LOW / informational):** The room token TTL default (15 min, 1A §3.3) is reasonable, but the spec does not bound the maximum configurable TTL or cap the number of auto-refreshes while the lobby is open. An indefinitely open lobby with continuous auto-refresh means the admission window never actually closes until the host manually closes it. The present cooperative-LAN trust posture (D3) makes this acceptable, but if the trust model tightens in a later phase this should be re-evaluated. No action required now.

- **LMCD-RC3-09-SEC-002 (LOW / informational):** 1B §3 requires QR credential handling to "stop/rotate after the match" and "don't encode reusable iOS hotspot passwords by default." There is no test-oracle item or acceptance criterion tied specifically to the iOS hotspot-password non-encoding rule. Given iOS Personal Hotspot is manual and the spec already states "by default," this is low risk, but a future reviewer should ensure the implementation does not silently fall back to encoding a reusable credential.

---

## Bottom line

CLEAR. All four round-2 issues (RC2-09-SEC-001, RC2-09-SEC-002, RC2-09-SEC-003, SEC-003) are fully addressed in v3 with explicit text, test oracle requirements, and exit-gate entries. No new BLOCKER or MAJOR security issues identified. Two LOW/informational observations are noted above but do not block implementation.
