# Network Round-3 Verification — v3

**Reviewer:** Network Engineer (role 04)
**Date:** 2026-06-20
**Scope:** v3 docs (connectivity-design, foundations, phase1a-lan-mvp, phase1b-robustness)
**Prior round:** RC2 (3 issues carried: RC2-04-NET-001/002/003)

---

## Round-2 issue verdicts

### RC2-04-NET-001 (MAJOR) — Diagnostic ladder must have a mid-session re-entry path
**Verdict: RESOLVED**

1B §1.1 (diagnostic ladder) now explicitly states: "The ladder runs both **at connection time** and **on any mid-session disconnect** (`grace`/`disconnected`) — it is not connect-only. A mid-session classification feeds the same taxonomy (§1.2) and the reconnect/pause/AI flow (§2)."
Cited as RC2-NET-001 in the 1B traceability footer and the connectivity-design v2→v3 changelog.

### RC2-04-NET-002 (MINOR) — iOS "no internet — stay connected?" dialog in two-step hotspot join
**Verdict: RESOLVED**

1B §1.3 addresses it verbatim: "In the two-step join, anticipate the **iOS 'no internet connection — stay connected?' dialog** when a guest joins an internet-less host hotspot; UX must instruct 'Keep trying / Use without internet'." Cited as RC2-NET-002 in the 1B traceability footer.

### RC2-04-NET-003 (MINOR) — iOS Local Network denial = silent Bonjour failure; needs inference method
**Verdict: RESOLVED**

1B §1.1 step 5 specifies the inference: "On **iOS** a denied Local Network permission makes Bonjour/mDNS fail **silently** (no readable API error); infer denial from 'advertise/browse started but zero results + no system prompt re-shown' and route to the Settings deep-link." Cited as RC2-NET-003. The failure taxonomy row (§1.2) also maps "iOS Local Network denied" → "Allow local network to find tables" + "Open Settings / use QR".

---

## New issues

No new BLOCKER or MAJOR network issues found. The ladder, taxonomy, hotspot flow, token/QR lifecycle, mDNS inference, and address-selection sections are internally consistent and cross-referenced correctly.

Minor observations (below MAJOR threshold, no blocking):

- **1B §1.4 (address selection) is advisory only** — the algorithm for "choose a guest-routable address across Wi-Fi/hotspot/VPN/multi-interface" is deferred to implementation. This is acceptable given the spike in 1A §1.1 must validate reachability first, but the spec does not define the selection heuristic (e.g. prefer hotspot interface over general Wi-Fi when `LocalOnlyHotspot` is active, or pick the lowest-metric interface). Implementers may get this wrong on dual-interface Android hosts. Not a blocker for 1A, worth a note in the 1B implementation ticket.

- **1B §1.3 "client auto-disconnect on 'no internet' roaming"** is listed as a validation target for Android `LocalOnlyHotspot` but there is no corresponding taxonomy row or recovery UX specified for the Android variant of the "no internet" OS dialog. The iOS case is handled (RC2-NET-002); Android behavior on roaming/no-internet hotspot connect is OS-version-dependent and could silently drop the guest. Not a blocker since Android guests typically do not get the iOS-style prompt, but worth an explicit validation checklist entry.

These do not rise to MAJOR; no new IDs assigned.

---

## Bottom line

**NOT-CLEAR → CLEAR**

All three RC2 network issues are fully addressed in v3 with specific text, inference methods, and UX guidance. No new blockers or majors identified in the network domain. The network portions of v3 are clear to proceed.
