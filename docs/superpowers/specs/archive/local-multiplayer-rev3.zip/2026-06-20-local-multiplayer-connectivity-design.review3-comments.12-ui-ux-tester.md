# UI/UX Round-3 Verification — v3

**Reviewer:** 12 · UI/UX Tester
**Date:** 2026-06-20
**Scope:** v3 of all four specs (connectivity-design, foundations, phase1a-lan-mvp, phase1b-robustness)

---

## Round-2 issue verdicts

### RC2-12-UX-002 (HIGH) — game-over/rematch; browser guests not stranded

**RESOLVED.**

1A §3.7 (added in v3) defines the full flow: `GameOver` broadcast → podium on all
clients; host gets Rematch / End-table actions; browser guests see "Waiting for host
to start a rematch…" plus an explicit "Leave table" action; host-ends-table sends a
clean terminal state (no dead socket); late QR scans during `gameOver` return
`GAME_ALREADY_STARTED` with a rematch hint. The SeatView `phase === 'gameOver'`
mapping in Foundations §4.1 drives this. All cases are covered.

---

### RC2-12-UX-001 (MED) — QR/token expiry TTL + refresh trigger + visible countdown

**RESOLVED.**

1A §3.3 (RC2-QA-002, RC2-UX-001) specifies: room token TTL default **15 min**,
auto-refreshed while lobby is open, QR shows a visible expiry/refresh indicator, and
an expired token returns `Error{code: ROOM_TOKEN_EXPIRED}` with a "rescan" action.
The failure-taxonomy row in 1B §1.2 ("Stale QR / token TTL elapsed → 'This code
expired' → Rescan new code") confirms the user-visible error path. The spec does not
call for a countdown timer (it says "expiry/refresh indicator"), which is acceptable
— the QR refreshes automatically while the lobby is live, so the user is only ever
exposed to the expiry if something has already gone wrong.

Minor gap (non-blocking): the spec does not specify what the refresh indicator looks
like (timestamp, spinner, pulse animation) or whether the refresh is visible to
guests as well as the host. This is implementation detail, not a design hole.

---

### RC2-12-UX-003 (MED) — host AI-takeover timeout default/range + lobby-visible indicator

**RESOLVED.**

1B §2.3 (RC2-UX-003) specifies: default **30 s**, host-settable range **10–120 s**
(or "never → pause-only"), value shown in the lobby, and a **live countdown visible
to all seats** while a player is in `grace`. The seat model in Foundations §2.1
provides the `controller: 'ai'` and `connection: 'grace'` fields that drive the
indicator. The `SeatSummary` carries `controller` and `connection` so every client
can render the label; the countdown requires the grace timestamp which is not
explicitly in `SeatSummary` — see new issue LMCD-RC3-12-UX-001 below.

---

### UX-005 (round-1 partial) — failure-taxonomy rows populated

**RESOLVED.**

1B §1.2 now has a full table with nine populated rows covering: page-load failure,
`/healthz`-ok-but-WS-timeout, WS-refused, repeated-abnormal-close, stale QR,
`SEAT_TAKEN`/`TABLE_FULL`, `GAME_ALREADY_STARTED`, iOS Local Network denied, and
wrong-subnet manual IP. Each row has signal, likely cause, user-facing message,
primary/secondary action, and measurable timeout/retry budget (where applicable).
The spec explicitly tags this `(UX-005, QA-008)`.

---

### UX-011 (round-1 partial) — accessibility criteria made testable

**RESOLVED.**

1B §5 (RC2-UX a11y) lists five concrete, pass/fail criteria, each with an
enforcement mechanism:
1. Camera-free manual join — E2E test.
2. Keyboard-complete browser join/lobby/play — Playwright keyboard-only run.
3. Screen-reader announcements (connecting/your-turn/disconnected/AI-controlled/reconnected) — ARIA live regions, asserted in Playwright by role/aria-live presence.
4. Non-color-only status — automated axe audit in CI.
5. Scalable text + focus-on-error — asserted.

The spec explicitly states "Accessibility checks are part of the 1B exit gate, not
aspirational." No longer just intentions.

---

## New issues

### LMCD-RC3-12-UX-001 (MAJOR) — Grace countdown missing from SeatSummary / SeatView

**Location:** Foundations §4.1 (SeatView schema), 1B §2.3 (RC2-UX-003).

The spec requires "a live countdown visible to all seats while a player is in
`grace`" (1B §2.3). The `SeatSummary` in Foundations §4.1 exposes `controller` and
`connection` but **no timestamp** (e.g. `graceSince: number` or
`aiTakeoverAt: number`). Without a server-authoritative timestamp in the outgoing
`SeatView`/`SeatSummary`, clients cannot render a synchronized countdown — each
client would have to calculate locally from the moment they first observe
`connection: 'grace'`, which drifts on reconnect and produces inconsistent displays.

**Required fix:** add `graceSince` (or `aiTakeoverAt`) to `SeatSummary` or as a
top-level field in `SeatView`, emitted in every `SeatSnapshot`/`StateDelta` while
the seat is in grace. Alternatively, emit a dedicated `SeatGraceStarted` event
carrying the authoritative start time and the configured timeout, so all clients can
reconstruct the same countdown. This is not an implementation detail — it is a
missing field in a Phase 0 contract (Foundations).

---

### LMCD-RC3-12-UX-002 (MAJOR) — Rematch seat-token re-issuance: no guest acknowledgement UX path

**Location:** 1A §3.7 (RC2-UX-002).

The rematch flow states: "host re-issues seat tokens, clients transition
`gameOver → lobby → live`". The spec does not define what happens if a **browser
guest's tab is still open** but the guest is idle or has navigated away when the
rematch starts. A browser tab in `gameOver` state has no background-push mechanism —
if the host fires `GameStarted` while the guest is not watching, the guest misses the
transition. The spec's "Waiting for host to start a rematch…" copy implies the guest
is in a polling/listening state, but there is no WebSocket keep-alive or heartbeat
coverage for the `gameOver` phase (heartbeats are specified for in-game reconnect in
1B §2.2, but `gameOver` is terminal in the session-state machine of Foundations §3.3:
`… → left`).

**Required fix:** clarify whether the WS connection remains open (and heartbeats
continue) during `gameOver`/rematch-lobby, or define a re-join flow (guest
re-establishes connection using the original `seatToken` when the host broadcasts a
new lobby state). Without this, the "Waiting for host…" UI cannot reliably receive
the rematch signal.

---

### LMCD-RC3-12-UX-003 (MINOR) — QR refresh indicator spec is ambiguous for guests

**Location:** 1A §3.3 (RC2-UX-001).

The spec says the QR shows "a visible expiry/refresh indicator" but does not state
whether this is host-side only (lobby screen) or also guest-side (e.g. a native-app
guest who has scanned but not yet connected). If a guest has the join URL but the
room token silently rotated before they tapped "Join", they will hit
`ROOM_TOKEN_EXPIRED` with no in-app signal that a refresh happened. The failure
taxonomy handles this with "Rescan new code", but a guest who entered the URL
manually (no camera) has no rescan path — only "rescan" is listed as the action
(1B §1.2). The manual-entry fallback needs a "request fresh URL from host" or the
token TTL must be long enough to outlast reasonable manual-entry latency.

This is minor because the 15-min TTL makes the race narrow, but the manual-entry gap
should be acknowledged in the spec.

---

## Bottom line

**NOT-CLEAR.**

All four Round-2 tracked items are **RESOLVED** in v3. Two new **MAJOR** gaps were
found:

- **LMCD-RC3-12-UX-001**: grace countdown requires a server-authoritative timestamp
  in `SeatSummary`/`SeatView` — currently absent from the Foundations §4.1 schema.
  This is a Phase 0 contract gap that will break the 1B AI-takeover UX if not fixed
  before Foundations is implemented.
- **LMCD-RC3-12-UX-002**: rematch WS-connection lifecycle during `gameOver` is
  unspecified — the "Waiting for host…" UI has no defined receive path for the
  rematch signal once the session state machine reaches `left`.

Neither is a new blocker that invalidates the overall architecture, but both must be
resolved in the Foundations and 1A specs before those phases exit. One additional
MINOR gap (LMCD-RC3-12-UX-003) is noted for the manual-entry / token-refresh case.
